from django_celery_beat.models import PeriodicTask


class O2OToPeriodicTasks(PeriodicTask):
    """
    The test-case model of OneToOne relation.
    """
    pass
